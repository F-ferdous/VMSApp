import React from "react";

const AddDetails = () => {
  return <div>AddDetails</div>;
};

export default AddDetails;
